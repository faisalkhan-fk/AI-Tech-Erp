package com.aitech.erp.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.aitech.erp.models.LeaveRequest;
import com.aitech.erp.repository.LeaveRepository;
import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/leaves")
public class LeaveController {
  @Autowired LeaveRepository leaveRepository;
  @GetMapping
  public List<LeaveRequest> getAll() { return leaveRepository.findAll(); }
  @GetMapping("/employee/{id}")
  public List<LeaveRequest> getByEmployee(@PathVariable Long id) { return leaveRepository.findByEmployeeId(id); }
  @PostMapping
  public LeaveRequest apply(@RequestBody LeaveRequest leave) {
    leave.setStatus("PENDING");
    return leaveRepository.save(leave); 
  }
}