package com.aitech.erp.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.aitech.erp.models.Project;
import com.aitech.erp.repository.ProjectRepository;
import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/projects")
public class ProjectController {
  @Autowired ProjectRepository projectRepository;
  @GetMapping
  public List<Project> getAll() { return projectRepository.findAll(); }
  @PostMapping
  public Project create(@RequestBody Project project) { return projectRepository.save(project); }
}