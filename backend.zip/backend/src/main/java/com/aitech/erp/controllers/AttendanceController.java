package com.aitech.erp.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.aitech.erp.models.Attendance;
import com.aitech.erp.repository.AttendanceRepository;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {
  @Autowired
  AttendanceRepository attendanceRepository;

  @GetMapping
  public List<Attendance> getAllAttendance() {
    return attendanceRepository.findAll();
  }

  @GetMapping("/employee/{empId}")
  public List<Attendance> getAttendanceByEmployee(@PathVariable Long empId) {
    return attendanceRepository.findByEmployeeId(empId);
  }

  @PostMapping("/checkin")
  public Attendance checkIn(@RequestBody Attendance attendance) {
    attendance.setCheckIn(LocalTime.now());
    attendance.setDate(LocalDate.now());
    attendance.setStatus("PRESENT");
    return attendanceRepository.save(attendance);
  }

  @PostMapping("/checkout/{id}")
  public ResponseEntity<Attendance> checkOut(@PathVariable Long id) {
    return attendanceRepository.findById(id).map(record -> {
      record.setCheckOut(LocalTime.now());
      // Calculate basic working hours (simplified)
      java.time.Duration duration = java.time.Duration.between(record.getCheckIn(), record.getCheckOut());
      record.setWorkingHours(duration.toMinutes() / 60.0);
      return ResponseEntity.ok(attendanceRepository.save(record));
    }).orElse(ResponseEntity.notFound().build());
  }
}