package com.aitech.erp.services;
import org.springframework.stereotype.Service;

@Service
public class AIService {
  public String generateDailyReport() {
    return "AI Summary: The team completed 12 tasks today. Attendance is at 95%. Productivity is high, but Project Alpha is slightly behind schedule. Recommend reassigning 2 developers to Alpha.";
  }

  public String getTaskRecommendations(Long employeeId) {
    return "Based on past performance, Employee " + employeeId + " excels at Backend Development. Recommended to assign 'Implement JWT Auth' and 'Database Optimization' with priority HIGH.";
  }

  public String generatePerformanceSummary(Long employeeId) {
    return "Performance Score: 88/100. Employee has shown great leadership in recent sprints. 100% attendance this month. Recommended for a senior role evaluation.";
  }

  public String chatAssistant(String query) {
    if (query.toLowerCase().contains("leave")) return "Company policy allows 15 casual leaves and 10 sick leaves per year.";
    if (query.toLowerCase().contains("attendance")) return "Core working hours are 10 AM to 4 PM. You must complete 8 hours daily.";
    return "I am the AI Tech ERP assistant. I can answer HR, Leave, and Project related queries.";
  }
}