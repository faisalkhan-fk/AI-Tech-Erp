package com.aitech.erp.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.aitech.erp.models.Task;
import com.aitech.erp.repository.TaskRepository;
import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/tasks")
public class TaskController {
  @Autowired TaskRepository taskRepository;
  @GetMapping
  public List<Task> getAll() { return taskRepository.findAll(); }
  @GetMapping("/employee/{id}")
  public List<Task> getByEmployee(@PathVariable Long id) { return taskRepository.findByAssignedToId(id); }
  @PostMapping
  public Task create(@RequestBody Task task) { return taskRepository.save(task); }
}